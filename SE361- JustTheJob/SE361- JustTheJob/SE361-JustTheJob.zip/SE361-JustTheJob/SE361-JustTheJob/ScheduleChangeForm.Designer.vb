﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScheduleChangeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtCABrief = New System.Windows.Forms.TextBox()
        Me.txtCALength = New System.Windows.Forms.TextBox()
        Me.txtCATime = New System.Windows.Forms.TextBox()
        Me.txtCALocation = New System.Windows.Forms.TextBox()
        Me.txtCADate = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtCAName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblNAHead = New System.Windows.Forms.Label()
        Me.btnSCBack = New System.Windows.Forms.Button()
        Me.btnSCEdit = New System.Windows.Forms.Button()
        Me.btnSCCancel = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtCABrief)
        Me.GroupBox1.Controls.Add(Me.txtCALength)
        Me.GroupBox1.Controls.Add(Me.txtCATime)
        Me.GroupBox1.Controls.Add(Me.txtCALocation)
        Me.GroupBox1.Controls.Add(Me.txtCADate)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtCAName)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.GroupBox1.Location = New System.Drawing.Point(12, 63)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(593, 265)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Appointment Information"
        '
        'txtCABrief
        '
        Me.txtCABrief.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCABrief.Location = New System.Drawing.Point(144, 159)
        Me.txtCABrief.Multiline = True
        Me.txtCABrief.Name = "txtCABrief"
        Me.txtCABrief.Size = New System.Drawing.Size(412, 96)
        Me.txtCABrief.TabIndex = 11
        '
        'txtCALength
        '
        Me.txtCALength.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCALength.Location = New System.Drawing.Point(498, 122)
        Me.txtCALength.Name = "txtCALength"
        Me.txtCALength.Size = New System.Drawing.Size(58, 20)
        Me.txtCALength.TabIndex = 10
        '
        'txtCATime
        '
        Me.txtCATime.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCATime.Location = New System.Drawing.Point(482, 95)
        Me.txtCATime.Name = "txtCATime"
        Me.txtCATime.Size = New System.Drawing.Size(74, 20)
        Me.txtCATime.TabIndex = 9
        '
        'txtCALocation
        '
        Me.txtCALocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCALocation.Location = New System.Drawing.Point(354, 43)
        Me.txtCALocation.Name = "txtCALocation"
        Me.txtCALocation.Size = New System.Drawing.Size(202, 20)
        Me.txtCALocation.TabIndex = 8
        '
        'txtCADate
        '
        Me.txtCADate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCADate.Location = New System.Drawing.Point(434, 69)
        Me.txtCADate.Name = "txtCADate"
        Me.txtCADate.Size = New System.Drawing.Size(122, 20)
        Me.txtCADate.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(7, 162)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Appointment Brief:"
        '
        'txtCAName
        '
        Me.txtCAName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCAName.Location = New System.Drawing.Point(407, 17)
        Me.txtCAName.Name = "txtCAName"
        Me.txtCAName.Size = New System.Drawing.Size(149, 20)
        Me.txtCAName.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(7, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 13)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Approximate Length:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(7, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Appointment Time:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(7, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Appointment Location:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(7, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Appointment Date:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(7, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Name:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(617, 24)
        Me.MenuStrip1.TabIndex = 13
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'BackToolStripMenuItem
        '
        Me.BackToolStripMenuItem.Name = "BackToolStripMenuItem"
        Me.BackToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.BackToolStripMenuItem.Text = "&Back"
        '
        'lblNAHead
        '
        Me.lblNAHead.AutoSize = True
        Me.lblNAHead.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNAHead.Location = New System.Drawing.Point(204, 40)
        Me.lblNAHead.Name = "lblNAHead"
        Me.lblNAHead.Size = New System.Drawing.Size(192, 20)
        Me.lblNAHead.TabIndex = 14
        Me.lblNAHead.Text = "Change Appointment Info"
        '
        'btnSCBack
        '
        Me.btnSCBack.Location = New System.Drawing.Point(494, 350)
        Me.btnSCBack.Name = "btnSCBack"
        Me.btnSCBack.Size = New System.Drawing.Size(103, 23)
        Me.btnSCBack.TabIndex = 15
        Me.btnSCBack.Text = "&Back"
        Me.btnSCBack.UseVisualStyleBackColor = True
        '
        'btnSCEdit
        '
        Me.btnSCEdit.Location = New System.Drawing.Point(376, 350)
        Me.btnSCEdit.Name = "btnSCEdit"
        Me.btnSCEdit.Size = New System.Drawing.Size(103, 23)
        Me.btnSCEdit.TabIndex = 16
        Me.btnSCEdit.Text = "&Apply Changes"
        Me.btnSCEdit.UseVisualStyleBackColor = True
        '
        'btnSCCancel
        '
        Me.btnSCCancel.Location = New System.Drawing.Point(12, 350)
        Me.btnSCCancel.Name = "btnSCCancel"
        Me.btnSCCancel.Size = New System.Drawing.Size(131, 23)
        Me.btnSCCancel.TabIndex = 17
        Me.btnSCCancel.Text = "&Cancel Appointment"
        Me.btnSCCancel.UseVisualStyleBackColor = True
        '
        'ScheduleChangeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(617, 384)
        Me.Controls.Add(Me.btnSCCancel)
        Me.Controls.Add(Me.btnSCEdit)
        Me.Controls.Add(Me.btnSCBack)
        Me.Controls.Add(Me.lblNAHead)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "ScheduleChangeForm"
        Me.Text = "Modify Appointment Form"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCABrief As System.Windows.Forms.TextBox
    Friend WithEvents txtCALength As System.Windows.Forms.TextBox
    Friend WithEvents txtCATime As System.Windows.Forms.TextBox
    Friend WithEvents txtCALocation As System.Windows.Forms.TextBox
    Friend WithEvents txtCADate As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtCAName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblNAHead As System.Windows.Forms.Label
    Friend WithEvents btnSCBack As System.Windows.Forms.Button
    Friend WithEvents btnSCEdit As System.Windows.Forms.Button
    Friend WithEvents btnSCCancel As System.Windows.Forms.Button
End Class
