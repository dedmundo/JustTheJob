﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmployeeInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnEIBack = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblEIEmail = New System.Windows.Forms.Label()
        Me.lblEIMobile = New System.Windows.Forms.Label()
        Me.lblEIHome = New System.Windows.Forms.Label()
        Me.lblEIAddress = New System.Windows.Forms.Label()
        Me.lblEIName = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblEIPhoneEM = New System.Windows.Forms.Label()
        Me.lblEINameEM = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblEIWages = New System.Windows.Forms.Label()
        Me.lblEIPayType = New System.Windows.Forms.Label()
        Me.lblEIPosition = New System.Windows.Forms.Label()
        Me.lblwage = New System.Windows.Forms.Label()
        Me.lblNEPay = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnEIEdit = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.lblEIHeading = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnEIBack
        '
        Me.btnEIBack.Location = New System.Drawing.Point(407, 508)
        Me.btnEIBack.Name = "btnEIBack"
        Me.btnEIBack.Size = New System.Drawing.Size(103, 23)
        Me.btnEIBack.TabIndex = 4
        Me.btnEIBack.Text = "&Back"
        Me.btnEIBack.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(525, 24)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'BackToolStripMenuItem
        '
        Me.BackToolStripMenuItem.Name = "BackToolStripMenuItem"
        Me.BackToolStripMenuItem.Size = New System.Drawing.Size(99, 22)
        Me.BackToolStripMenuItem.Text = "&Back"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblEIEmail)
        Me.GroupBox1.Controls.Add(Me.lblEIMobile)
        Me.GroupBox1.Controls.Add(Me.lblEIHome)
        Me.GroupBox1.Controls.Add(Me.lblEIAddress)
        Me.GroupBox1.Controls.Add(Me.lblEIName)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.GroupBox1.Location = New System.Drawing.Point(12, 97)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(498, 264)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Information"
        '
        'lblEIEmail
        '
        Me.lblEIEmail.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIEmail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIEmail.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIEmail.Location = New System.Drawing.Point(308, 142)
        Me.lblEIEmail.Name = "lblEIEmail"
        Me.lblEIEmail.Size = New System.Drawing.Size(161, 23)
        Me.lblEIEmail.TabIndex = 17
        Me.lblEIEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIMobile
        '
        Me.lblEIMobile.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIMobile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIMobile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIMobile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIMobile.Location = New System.Drawing.Point(372, 111)
        Me.lblEIMobile.Name = "lblEIMobile"
        Me.lblEIMobile.Size = New System.Drawing.Size(97, 23)
        Me.lblEIMobile.TabIndex = 16
        Me.lblEIMobile.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIHome
        '
        Me.lblEIHome.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIHome.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIHome.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIHome.Location = New System.Drawing.Point(372, 84)
        Me.lblEIHome.Name = "lblEIHome"
        Me.lblEIHome.Size = New System.Drawing.Size(97, 23)
        Me.lblEIHome.TabIndex = 15
        Me.lblEIHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIAddress
        '
        Me.lblEIAddress.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIAddress.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIAddress.Location = New System.Drawing.Point(308, 52)
        Me.lblEIAddress.Name = "lblEIAddress"
        Me.lblEIAddress.Size = New System.Drawing.Size(164, 23)
        Me.lblEIAddress.TabIndex = 14
        Me.lblEIAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIName
        '
        Me.lblEIName.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIName.Location = New System.Drawing.Point(333, 22)
        Me.lblEIName.Name = "lblEIName"
        Me.lblEIName.Size = New System.Drawing.Size(139, 23)
        Me.lblEIName.TabIndex = 13
        Me.lblEIName.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(7, 142)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Email:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblEIPhoneEM)
        Me.GroupBox2.Controls.Add(Me.lblEINameEM)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.Desktop
        Me.GroupBox2.Location = New System.Drawing.Point(10, 170)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(482, 88)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Emergency Contacts:"
        '
        'lblEIPhoneEM
        '
        Me.lblEIPhoneEM.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIPhoneEM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIPhoneEM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIPhoneEM.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIPhoneEM.Location = New System.Drawing.Point(362, 53)
        Me.lblEIPhoneEM.Name = "lblEIPhoneEM"
        Me.lblEIPhoneEM.Size = New System.Drawing.Size(97, 23)
        Me.lblEIPhoneEM.TabIndex = 18
        Me.lblEIPhoneEM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEINameEM
        '
        Me.lblEINameEM.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEINameEM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEINameEM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEINameEM.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEINameEM.Location = New System.Drawing.Point(323, 22)
        Me.lblEINameEM.Name = "lblEINameEM"
        Me.lblEINameEM.Size = New System.Drawing.Size(136, 23)
        Me.lblEINameEM.TabIndex = 17
        Me.lblEINameEM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(7, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Contact Phone:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(7, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Contact Name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(7, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(97, 13)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Mobile/Cell Phone:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(6, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Home Phone:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(7, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Home Address:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(7, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Employee Name:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblEIWages)
        Me.GroupBox3.Controls.Add(Me.lblEIPayType)
        Me.GroupBox3.Controls.Add(Me.lblEIPosition)
        Me.GroupBox3.Controls.Add(Me.lblwage)
        Me.GroupBox3.Controls.Add(Me.lblNEPay)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.Desktop
        Me.GroupBox3.Location = New System.Drawing.Point(12, 367)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(498, 124)
        Me.GroupBox3.TabIndex = 15
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Work Information"
        '
        'lblEIWages
        '
        Me.lblEIWages.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIWages.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIWages.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIWages.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIWages.Location = New System.Drawing.Point(372, 96)
        Me.lblEIWages.Name = "lblEIWages"
        Me.lblEIWages.Size = New System.Drawing.Size(97, 23)
        Me.lblEIWages.TabIndex = 21
        Me.lblEIWages.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIPayType
        '
        Me.lblEIPayType.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIPayType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIPayType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIPayType.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIPayType.Location = New System.Drawing.Point(372, 58)
        Me.lblEIPayType.Name = "lblEIPayType"
        Me.lblEIPayType.Size = New System.Drawing.Size(97, 23)
        Me.lblEIPayType.TabIndex = 20
        Me.lblEIPayType.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblEIPosition
        '
        Me.lblEIPosition.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIPosition.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIPosition.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIPosition.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblEIPosition.Location = New System.Drawing.Point(333, 28)
        Me.lblEIPosition.Name = "lblEIPosition"
        Me.lblEIPosition.Size = New System.Drawing.Size(136, 23)
        Me.lblEIPosition.TabIndex = 19
        Me.lblEIPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblwage
        '
        Me.lblwage.AutoSize = True
        Me.lblwage.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwage.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblwage.Location = New System.Drawing.Point(7, 96)
        Me.lblwage.Name = "lblwage"
        Me.lblwage.Size = New System.Drawing.Size(44, 13)
        Me.lblwage.TabIndex = 15
        Me.lblwage.Text = "Wages:"
        '
        'lblNEPay
        '
        Me.lblNEPay.AutoSize = True
        Me.lblNEPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNEPay.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNEPay.Location = New System.Drawing.Point(31, 96)
        Me.lblNEPay.Name = "lblNEPay"
        Me.lblNEPay.Size = New System.Drawing.Size(0, 13)
        Me.lblNEPay.TabIndex = 10
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(6, 68)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(55, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Pay Type:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(6, 28)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(67, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Job Position:"
        '
        'btnEIEdit
        '
        Me.btnEIEdit.Location = New System.Drawing.Point(298, 508)
        Me.btnEIEdit.Name = "btnEIEdit"
        Me.btnEIEdit.Size = New System.Drawing.Size(103, 23)
        Me.btnEIEdit.TabIndex = 17
        Me.btnEIEdit.Text = "&Edit Employee"
        Me.btnEIEdit.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemove.Location = New System.Drawing.Point(21, 508)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(111, 23)
        Me.btnRemove.TabIndex = 18
        Me.btnRemove.Text = "&Delete Employee"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'lblEIHeading
        '
        Me.lblEIHeading.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblEIHeading.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEIHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEIHeading.Location = New System.Drawing.Point(139, 60)
        Me.lblEIHeading.Name = "lblEIHeading"
        Me.lblEIHeading.Size = New System.Drawing.Size(260, 23)
        Me.lblEIHeading.TabIndex = 20
        Me.lblEIHeading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(136, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(263, 25)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Employee Information For:"
        '
        'EmployeeInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 540)
        Me.Controls.Add(Me.lblEIHeading)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnEIEdit)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnEIBack)
        Me.Name = "EmployeeInfo"
        Me.Text = "Employee Information Form"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnEIBack As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblEIEmail As System.Windows.Forms.Label
    Friend WithEvents lblEIMobile As System.Windows.Forms.Label
    Friend WithEvents lblEIHome As System.Windows.Forms.Label
    Friend WithEvents lblEIAddress As System.Windows.Forms.Label
    Friend WithEvents lblEIName As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblEIPhoneEM As System.Windows.Forms.Label
    Friend WithEvents lblEINameEM As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lblEIPayType As System.Windows.Forms.Label
    Friend WithEvents lblEIPosition As System.Windows.Forms.Label
    Friend WithEvents lblwage As System.Windows.Forms.Label
    Friend WithEvents lblNEPay As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblEIWages As System.Windows.Forms.Label
    Friend WithEvents btnEIEdit As System.Windows.Forms.Button
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents lblEIHeading As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
